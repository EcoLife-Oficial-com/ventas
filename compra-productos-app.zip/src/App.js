import React, { useState } from 'react';
import './App.css';

const productos = {
  comestible: [
    { nombre: 'Arroz', tipo: 'libra', precio: 30 },
    { nombre: 'Carne', tipo: 'libra', precio: 60 },
    { nombre: 'Huevo', tipo: 'unidad', precio: 10 },
  ],
  noComestible: [
    { nombre: 'Cepillo de dientes', tipo: 'unidad', precio: 25 },
    { nombre: 'Pasta dental', tipo: 'unidad', precio: 35 },
    { nombre: 'Jabón', tipo: 'unidad', precio: 15 },
  ],
};

function App() {
  const [tipoSeleccionado, setTipoSeleccionado] = useState('');
  const [productoSeleccionado, setProductoSeleccionado] = useState(null);
  const [cantidad, setCantidad] = useState(1);
  const [carrito, setCarrito] = useState([]);
  const [formaPago, setFormaPago] = useState('');
  const [pasoFinal, setPasoFinal] = useState(false);

  const handleAgregarAlCarrito = () => {
    if (productoSeleccionado) {
      const total = productoSeleccionado.precio * cantidad;
      const nuevoItem = {
        nombre: productoSeleccionado.nombre,
        tipo: productoSeleccionado.tipo,
        cantidad,
        total,
      };
      setCarrito([...carrito, nuevoItem]);
      setProductoSeleccionado(null);
      setCantidad(1);
    }
  };

  const totalCarrito = carrito.reduce((acc, item) => acc + item.total, 0);

  const productosDisponibles = tipoSeleccionado ? productos[tipoSeleccionado] : [];

  const handleVolver = () => {
    setPasoFinal(false);
    setFormaPago('');
  };

  return (
    <div className="App">
      <h1>Compra de Productos</h1>

      {!pasoFinal && (
        <>
          <div>
            <label>Selecciona el tipo de producto: </label>
            <select onChange={e => setTipoSeleccionado(e.target.value)}>
              <option value=''>-- Seleccionar --</option>
              <option value='comestible'>Comestible</option>
              <option value='noComestible'>No comestible</option>
            </select>
          </div>

          {tipoSeleccionado && (
            <div>
              <label>Selecciona un producto: </label>
              <select onChange={e => {
                const producto = productosDisponibles.find(p => p.nombre === e.target.value);
                setProductoSeleccionado(producto);
              }}>
                <option value=''>-- Seleccionar --</option>
                {productosDisponibles.map(p => (
                  <option key={p.nombre} value={p.nombre}>{p.nombre} - {p.tipo} - ${p.precio}</option>
                ))}
              </select>
            </div>
          )}

          {productoSeleccionado && (
            <div>
              <label>Cantidad ({productoSeleccionado.tipo}): </label>
              <input
                type='number'
                value={cantidad}
                min='1'
                onChange={e => setCantidad(parseInt(e.target.value))}
              />
              <button onClick={handleAgregarAlCarrito}>Agregar al carrito</button>
            </div>
          )}

          <div className="carrito">
            <h3>Carrito</h3>
            <ul>
              {carrito.map((item, idx) => (
                <li key={idx}>{item.nombre} ({item.cantidad} {item.tipo}) - ${item.total}</li>
              ))}
            </ul>
            <strong>Total: ${totalCarrito}</strong>
            {carrito.length > 0 && (
              <button onClick={() => setPasoFinal(true)}>Proceder al pago</button>
            )}
          </div>
        </>
      )}

      {pasoFinal && (
        <div className="pago">
          <h3>Forma de pago</h3>
          <select onChange={e => setFormaPago(e.target.value)}>
            <option value=''>-- Seleccionar método --</option>
            <option value='efectivo'>Efectivo</option>
            <option value='tarjeta'>Tarjeta</option>
            <option value='transferencia'>Transferencia</option>
          </select>

          {formaPago && (
            <div className="resumen">
              <h4>Resumen de compra:</h4>
              <ul>
                {carrito.map((item, idx) => (
                  <li key={idx}>{item.nombre} ({item.cantidad} {item.tipo}) - ${item.total}</li>
                ))}
              </ul>
              <strong>Total a pagar: ${totalCarrito}</strong>
              <p>Pago por: {formaPago}</p>
              <button onClick={handleVolver}>Volver a productos</button>
              <button>Finalizar compra</button>
              <div className='chat-box'>
                <h5>¿Tienes dudas? Escribe al chat</h5>
                <textarea placeholder='Escribe tu mensaje aquí...'></textarea>
                <button>Enviar</button>
              </div>
            </div>
          )}
        </div>
      )}
    </div>
  );
}

export default App;